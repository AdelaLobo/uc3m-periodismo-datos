# Trabajo final de Periodismo de Datos
## ¡Bienvenidxs a mi página web!
En este sitio podrás encontrar todo mi trabajo de la asignatura de **Periodismo de datos** 
Desde la cabecera puedes navegar por las diferentes prácticas. 

- En la pestaña *Práctica 1*, se ofrecen dos comentarios de dos infografías. Esta práctica se realizó al principio del cuatrimestre, cuando sabía menos sobre el tema
- En la práctica 2, se puede consultar el comentaría de otra infografía. Aquí se puede comprobar que se ha adquirido un mayor conocimiento sobre las visualizaciones de datos.
- La práctica 3 es un trabajo de elaboración de un gráfico. Se trabajó con un archivo *.csv* proporcionado por el profesor, *OpenRefine* y *Datawrapper*.
- La práctica 4 también es una elaboración de una visualización de datos. En este caso, se empleó una base de datos alternativa a la ofrecida por el profesor. 

Y esta es la última práctica del curso, donde se expone todo el trabajo realizado en esta asignatura.
